import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

class Account {
	private String name;
	private ArrayList<Transaction> transactions = new ArrayList<>();
	private int id;
	private double balance;
	private static double annualInterestRate;
	private Date dateCreated;
	
	public Account() {
		dateCreated = new Date(System.currentTimeMillis());
	}
	
	public Account(String name, int id, double balance) {
		this.name = name;
		this.id = id;
		this.balance = balance;
	}
	
	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}
	
	public void setAnnualInterestRate(double newAIR) {
		annualInterestRate = newAIR;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate; 
	}
	
	public String getDateCreated() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
		return sdf.format(this.dateCreated.getTime());
	}
	
	public void setBalance(double newBalance) {
		this.balance = newBalance;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setId(int newId) {
		this.id = newId;
	}
	
	public int getId() {
		return this.id;
	}
	
	public double getMonthlyInterest() {
		return balance*(annualInterestRate / 1200);
	}
	
	public void withdraw(double amount, String description) {
		if (amount > 0 && amount <= this.balance) {
			this.balance -= amount;
			transactions.add(new Transaction('W', amount, balance, description));
		}	
	}
	
	public void deposit(double amount, String description) {
		if (amount > 0) {
			this.balance += amount;
			transactions.add(new Transaction('D', amount, balance, description));
		}
	}
}